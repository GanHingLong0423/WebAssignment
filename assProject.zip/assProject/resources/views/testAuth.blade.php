@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Authentication page</h1>
</div>
@endsection